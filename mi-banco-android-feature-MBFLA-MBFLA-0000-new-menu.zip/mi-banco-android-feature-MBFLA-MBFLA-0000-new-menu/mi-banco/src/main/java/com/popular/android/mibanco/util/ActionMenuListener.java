package com.popular.android.mibanco.util;

import android.content.Context;

public interface ActionMenuListener {
    void onClick(Context context);
}
