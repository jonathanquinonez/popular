package com.popular.android.mibanco.util.enums;

public interface RegainAccessTypeEnum {

    String USERNAME = "userid";
    String PASSWORD = "psw";
    String BLOCKED = "blocked";

}
