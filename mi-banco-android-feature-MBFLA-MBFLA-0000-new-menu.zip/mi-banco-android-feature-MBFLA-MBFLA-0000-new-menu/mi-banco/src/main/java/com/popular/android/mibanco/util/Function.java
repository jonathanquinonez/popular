package com.popular.android.mibanco.util;

public interface Function<E, T> {

    T apply(E input);
}
