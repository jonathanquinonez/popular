package com.popular.android.mibanco.ws.response;

import java.io.Serializable;

public class AthmSendMoneyInput extends AthmResponse implements Serializable {
}
