package com.popular.android.mibanco.listener;

/**
 * Task listener interface
 */
public interface TaskListener {
}
