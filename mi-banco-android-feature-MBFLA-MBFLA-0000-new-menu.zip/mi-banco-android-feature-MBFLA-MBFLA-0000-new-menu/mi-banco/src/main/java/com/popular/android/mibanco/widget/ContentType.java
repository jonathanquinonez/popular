package com.popular.android.mibanco.widget;

public enum ContentType {
    LOGIN, HIDDEN_ACCOUNTS, BALANCES
}
