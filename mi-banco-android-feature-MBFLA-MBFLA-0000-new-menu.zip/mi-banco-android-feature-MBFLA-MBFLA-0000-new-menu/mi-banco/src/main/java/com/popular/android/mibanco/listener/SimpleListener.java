package com.popular.android.mibanco.listener;

public interface SimpleListener extends TaskListener {
    void done();
}
