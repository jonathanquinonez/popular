package com.popular.android.mibanco.ws.response;

import java.io.Serializable;

public class AthmEnrollAccount extends AthmResponse implements Serializable {
}
