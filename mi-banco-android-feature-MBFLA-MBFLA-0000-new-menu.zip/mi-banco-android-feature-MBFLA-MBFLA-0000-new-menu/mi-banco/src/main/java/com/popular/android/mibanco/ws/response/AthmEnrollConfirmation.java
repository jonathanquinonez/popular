package com.popular.android.mibanco.ws.response;

import java.io.Serializable;

public class AthmEnrollConfirmation extends AthmResponse implements Serializable {
}
