package com.popular.android.mibanco.listener;

/**
 * Interface class to implement listener for objects
 */
public interface ObjectListener extends TaskListener {
    void done(Object data);
}
